/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quickchatpart2;

/**
 *
 * @author uyand
 */

import java.util.Random;
import java.util.Scanner;

public class quickchatpart2{

    static Scanner input = new Scanner(System.in);

    static String username;
    static String password;
    static String cellphone;


    public static boolean checkUsername(String username) {

        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean checkPassword(String password) {

        String regex =
                "^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&*!]).{8,}$";

        return password.matches(regex);
    }

    public static boolean checkCellphone(String cellphone) {

        String regex = "^\\+27[0-9]{9}$";

        return cellphone.matches(regex);
    }

    public static void registerUser() {

        System.out.println("Create Username:");
        username = input.nextLine();

        if (checkUsername(username)) {

            System.out.println(
                    "Username successfully captured");

        } else {

            System.out.println(
                    "Username incorrectly formatted");
        }

        System.out.println("Create Password:");
        password = input.nextLine();

        if (checkPassword(password)) {

            System.out.println(
                    "Password successfully captured");

        } else {

            System.out.println(
                    "Password incorrectly formatted");
        }

        System.out.println("Enter cellphone number:");
        cellphone = input.nextLine();

        if (checkCellphone(cellphone)) {

            System.out.println(
                    "Cellphone successfully added");

        } else {

            System.out.println(
                    "Cellphone incorrectly formatted");
        }
    }

    public static boolean loginUser() {

        System.out.println("Enter Username:");
        String enteredUsername = input.nextLine();

        System.out.println("Enter Password:");
        String enteredPassword = input.nextLine();

        if (enteredUsername.equals(username)
                && enteredPassword.equals(password)) {

            return true;

        } else {

            return false;
        }
    }

    public static String returnLoginStatus(boolean login) {

        if (login == true) {

            return "Welcome " + username
                    + " it is great to see you again.";

        } else {

            return "Username or password incorrect.";
        }
    }

    public static boolean checkMessageLength(String message) {

        if (message.length() <= 250) {

            return true;

        } else {

            return false;
        }
    }

    public static boolean checkRecipient(String recipient) {

        String regex = "^\\+27[0-9]{9}$";

        return recipient.matches(regex);
    }

    public static String createMessageID() {

        Random random = new Random();

        int number =
                100000000 + random.nextInt(900000000);

        return String.valueOf(number);
    }

    public static String createMessageHash(
            String messageID,
            int messageNumber,
            String message) {

        String[] words = message.split(" ");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        String hash =
                messageID.substring(0, 2)
                + ":" + messageNumber
                + ":" + firstWord.toUpperCase()
                + lastWord.toUpperCase();

        return hash;
    }

    public static void main(String[] args) {

        System.out.println("===== REGISTER =====");

        registerUser();

        System.out.println("\n===== LOGIN =====");

        boolean login = loginUser();

        System.out.println(
                returnLoginStatus(login));
        if (login == true) {

            System.out.println(
                    "\nWelcome to QuickChat");

            int option;

            do {

                System.out.println("\n===== MENU =====");

                System.out.println(
                        "1. Send Messages");

                System.out.println(
                        "2. Show recently sent messages");

                System.out.println(
                        "3. Quit");

                System.out.println(
                        "Choose option:");

                option = input.nextInt();

                input.nextLine();

                switch (option) {

                    case 1:

                        System.out.println(
                                "How many messages do you want to send?");

                        int totalMessages =
                                input.nextInt();

                        input.nextLine();

                        for (int i = 1;
                             i <= totalMessages;
                             i++) {

                            System.out.println(
                                    "\nMessage " + i);

                            System.out.println(
                                    "Enter recipient number:");

                            String recipient =
                                    input.nextLine();

                            if (!checkRecipient(recipient)) {

                                System.out.println(
                                        "Cellphone number incorrectly formatted");

                                continue;
                            }
                            
                            System.out.println(
                                    "Enter your message:");

                            String message =
                                    input.nextLine();

                            if (!checkMessageLength(message)) {

                                int extra =
                                        message.length() - 250;

                                System.out.println(
                                        "Message exceeds 250 characters by "
                                                + extra
                                                + " characters");

                                continue;
                            }

                            // MESSAGE ID
                            String messageID =
                                    createMessageID();

                            String hash =
                                    createMessageHash(
                                            messageID,
                                            i,
                                            message);

                            System.out.println(
                                    "\nMessage successfully sent");

                            System.out.println(
                                    "--------------------------------");

                            System.out.println(
                                    "Message ID: "
                                            + messageID);

                            System.out.println(
                                    "Message Hash: "
                                            + hash);

                            System.out.println(
                                    "Recipient: "
                                            + recipient);

                            System.out.println(
                                    "Message: "
                                            + message);

                            System.out.println(
                                    "--------------------------------");
                        }

                        break;

                    case 2:

                        System.out.println(
                                "Coming Soon");

                        break;

                    case 3:

                        System.out.println(
                                "Goodbye");

                        break;

                    default:

                        System.out.println(
                                "Invalid option");
                }

            } while (option != 3);
        }
    }
}